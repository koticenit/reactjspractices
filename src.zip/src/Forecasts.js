//import React from 'react';
import logo from './logo.svg';
import rain from './rain.png';
import './App.css';
// import React  from 'react';
import React, { useState, useEffect } from "react";

// const gitHubUrl ="http://api.openweathermap.org/data/2.5/forecast?q=hyderabad&cnt=4&appid=ce5cbb754c954329a69f2f8083ebedb9";
const gitHubUrl ="http://api.openweathermap.org/data/2.5/forecast?q=hyderabad&appid=ce5cbb754c954329a69f2f8083ebedb9";

function Forecasts() {

  const [userData, setUserData] = useState({});
  const [userList, setList] = useState([]);
  const [userWeather, setWeather] = useState([]);

  

  let date='2020-10-12';

  useEffect(() => {
    getGitHubUserWithFetchs();
  }, []);

  
  const getGitHubUserWithFetchs  = async () => {
    const response = await fetch(gitHubUrl);
    const jsonData = await response.json();
    setUserData(jsonData);
    setList(jsonData.list);
    
    
  };

  // const navigateTo = () => history.push('/componentURL');//eg.history.push('/login');

  return (
    <div>
      <h1>Weather App</h1>
        <div class="centered">
        <h1> Call 5 day / 3 hour forecast data  </h1>
        </div>
        <div class="demo">
          <div> 
              <br />
              <h1 class="margin-center">Location : Hyderabad</h1>
            
                {userList.filter(name => name.dt_txt.includes(date)).map((forecast,index) => (
              
              <div key={index} class="forecastdiv">
              <div><br/>{forecast.dt_txt.dateDMY}{new Date( forecast.dt_txt ).toDateString()}<br/><img src={rain} alt="Smiley face" class="rainimage"/><br/>
              <h4>Temp:{forecast.main.temp}</h4><br/>
               {forecast.weather[0].description}
              </div>  
              </div>


              ))};
          </div>
    
       </div>
    </div>
   
  );
}

export default Forecasts;
